# AFDSE-TVAF Static Harmonic Evaluation

This folder contains the test reported as Fig. 4 and Table IV in the accompanying paper.

## Contents

- `AFDSE_TVAF_Pseudocode.m`: MATLAB-style processing sequence (framework);
- `filters/filter_responses.csv`: the amplitude-frequency responses of the three
  FIR low-pass filters of Table II;
- `results/TableIV_static_harmonic_max_errors.csv`: the
  maximum TVE, FE and RFE over harmonic orders 2-50 at the four fundamental
frequencies printed in Table IV (48.5, 49.5, 50.5 and 51.5 Hz);

## Test signal

x(t) = 100 [cos(theta1) + 0.01 cos(n*theta1)], theta1 = 2*pi*f0*t; harmonic order
n = 2-50, each at 1 % of the fundamental; f0 = 48.5, 49.5, 50.5 and 51.5 Hz;
sampling rate 10 kHz; record length 0.2 s.
