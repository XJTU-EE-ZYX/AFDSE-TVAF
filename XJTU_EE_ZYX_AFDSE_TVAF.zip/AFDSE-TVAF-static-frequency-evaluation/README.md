# AFDSE-TVAF Static Frequency-Deviation Evaluation

This folder contains the test reported as Fig. 3 and Table III in the accompanying paper.

## Contents

- `AFDSE_TVAF_Pseudocode.m`: MATLAB-style processing sequence (framework);
- `filters/filter_responses.csv`: the amplitude-frequency responses of the three
  FIR low-pass filters of Table II;
- `results/TableIII_static_frequency_max_errors.csv`: the
  maximum TVE, FE and RFE of AFDSE-TVAF, MDSEA and HDPE at the three frequency
points printed in Table III (45.0, 47.5 and 50.0 Hz);

## Test signal

x(t) = 100 cos(2*pi*f0*t); f0 swept over 45-55 Hz; sampling rate 10 kHz; record
length 0.2 s.
