# AFDSE-TVAF Dynamic Amplitude- and Phase-Step Evaluation

This folder contains the test reported as Fig. 7 and Table VI in the accompanying paper.

## Contents

- `AFDSE_TVAF_Pseudocode.m`: MATLAB-style processing sequence (framework);
- `filters/filter_responses.csv`: the amplitude-frequency responses of the three
  FIR low-pass filters of Table II;
- `results/TableVI_step_response_times.csv`: the
  TVE, FE and RFE response times of AFDSE-TVAF for the five magnitude steps
(10-30 %) and the five phase steps (10-15 deg) of Table VI, together with
the P-class limits;

## Test signal

x(t) = 100 [1 + km f1(t)] cos(2*pi*50*t + kp f1(t)), f1(t) = 0 for t < 0.3 s and
1 for t >= 0.3 s; magnitude steps km = 10, 15, 20, 25, 30 %; phase steps
kp = 10, 12, 13, 14, 15 deg; sampling rate 10 kHz; record 0.06-0.56 s.
