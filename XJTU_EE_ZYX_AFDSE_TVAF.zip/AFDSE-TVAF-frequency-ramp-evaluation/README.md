# AFDSE-TVAF Dynamic Frequency-Ramp Evaluation

This folder contains the test reported as Fig. 6 and Section IV-D in the accompanying paper.

## Contents

- `AFDSE_TVAF_Pseudocode.m`: MATLAB-style processing sequence (framework);
- `filters/filter_responses.csv`: the amplitude-frequency responses of the three
  FIR low-pass filters of Table II;
- `results/SectionIVD_frequency_ramp_max_errors.csv`: the
  maximum TVE, FE and RFE of AFDSE-TVAF within the valid test interval, as
reported in Section IV-D; the paper tabulates no MDSEA or HDPE values for
this test;

## Test signal

x(t) = 100 cos(phi(t)); frequency 45 Hz for t < 1 s, linear ramp of +1 Hz/s from
45 Hz to 55 Hz over 1 s <= t <= 11 s, 55 Hz afterwards; sampling rate 10 kHz;
record length 12 s.
