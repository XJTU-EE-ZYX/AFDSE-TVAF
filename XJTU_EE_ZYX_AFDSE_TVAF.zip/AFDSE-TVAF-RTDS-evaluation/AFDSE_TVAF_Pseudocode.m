function result = AFDSE_TVAF_Pseudocode(u1, time, configuration)
%AFDSE_TVAF_PSEUDOCODE MATLAB-style reference of the processing sequence.
%
% The two implementation-dependent stages are represented by documented
% interfaces. The remaining expressions follow the processing chain in the
% paper: finite-length HT, U(t), theta_u(t), U1(t), theta_1(t), and the
% synchrophasor output.

arguments
    u1 (:,1) double
    time (:,1) double
    configuration struct
end

if numel(u1) ~= numel(time)
    error('The signal and time vectors must have the same length.');
end

requiredConfiguration = {'fs','extension','filtering'};
missingConfiguration = requiredConfiguration( ...
    ~isfield(configuration,requiredConfiguration));
if ~isempty(missingConfiguration)
    error('Missing configuration fields: %s', ...
        strjoin(missingConfiguration,', '));
end

if numel(time) < 3 || any(~isfinite(time)) || any(~isfinite(u1))
    error('The input must contain at least three finite samples.');
end
if any(diff(time) <= 0)
    error('The time vector must be strictly increasing.');
end

Ts = 1/configuration.fs;
sampleInterval = diff(time);
if max(abs(sampleInterval-Ts)) > 1e-8*Ts
    error('The time vector is inconsistent with the configured sampling rate.');
end

inputInformation = struct;
inputInformation.sampleCount = numel(u1);
inputInformation.startTime_s = time(1);
inputInformation.endTime_s = time(end);
inputInformation.samplingInterval_s = Ts;
inputInformation.samplingFrequency_Hz = configuration.fs;

%% First finite-length Hilbert transform
[timeExtended, u1Extended, validIndex] = ...
    periodic_extension_interface(time, u1, configuration.extension);
if numel(timeExtended) ~= numel(u1Extended)
    error('The extension interface returned inconsistent vectors.');
end
analyticSignal = hilbert(u1Extended);
u2Extended = imag(analyticSignal);

u1Valid = u1Extended(validIndex);
u2Valid = u2Extended(validIndex);
timeValid = timeExtended(validIndex);

if isempty(timeValid)
    error('The extension interface returned an empty valid interval.');
end

%% Time-varying amplitude and phase
U = sqrt(u1Valid.^2 + u2Valid.^2);
thetaU = unwrap(atan2(u2Valid, u1Valid));
omegaU = gradient(thetaU, Ts);
frequencyU_Hz = omegaU/(2*pi);

%% Fundamental-amplitude branch
U1 = filtering_interface(U, 'synchrophasor', configuration.filtering);
if numel(U1) ~= numel(U)
    error('The synchrophasor branch returned an unexpected length.');
end

%% Second finite-length Hilbert transform and phase recovery
amplitudeResidual = U - U1;
[~, residualExtended, residualIndex] = ...
    periodic_extension_interface(timeValid, amplitudeResidual, ...
    configuration.extension);
residualAnalyticSignal = hilbert(residualExtended);
UaExtended = imag(residualAnalyticSignal);
Ua = UaExtended(residualIndex);

if numel(Ua) ~= numel(U1)
    error('The residual quadrature component has an unexpected length.');
end

phaseNumerator = U.*u2Valid - Ua.*u1Valid;
phaseDenominator = U.*u1Valid + Ua.*u2Valid;
theta1 = unwrap(atan2(phaseNumerator, phaseDenominator));
synchrophasor = U1.*exp(1j*theta1);

%% Frequency and ROCOF branches
omega0 = filtering_interface(omegaU, 'frequency', configuration.filtering);
frequencyHz = omega0/(2*pi);
omegaRocof = filtering_interface(omegaU, 'rocof', configuration.filtering);
rocofHzPerSecond = [diff(omegaRocof/(2*pi))/Ts; NaN];

finiteOutput = isfinite(U1) & isfinite(theta1) & ...
    isfinite(frequencyHz) & isfinite(rocofHzPerSecond);
reportingIndex = find(finiteOutput);

result = struct;
result.time = timeValid;
result.inputInformation = inputInformation;
result.u1 = u1Valid;
result.u2 = u2Valid;
result.U = U;
result.thetaU = thetaU;
result.frequencyU_Hz = frequencyU_Hz;
result.U1 = U1;
result.Ua = Ua;
result.theta1 = theta1;
result.synchrophasor = synchrophasor;
result.frequencyHz = frequencyHz;
result.rocofHzPerSecond = rocofHzPerSecond;
result.reportingIndex = reportingIndex;

%% Optional evaluation against supplied references
% A caller may provide reference phasor, frequency, and ROCOF sequences in
% configuration.reference. This block implements the definitions used by
% the public evaluation tables without changing the estimator.
if isfield(configuration,'reference')
    reference = configuration.reference;
    requiredReference = {'synchrophasor','frequencyHz','rocofHzPerSecond'};
    missingReference = requiredReference(~isfield(reference,requiredReference));
    if ~isempty(missingReference)
        error('Missing reference fields: %s',strjoin(missingReference,', '));
    end

    referencePhasor = reference.synchrophasor(:);
    referenceFrequency = reference.frequencyHz(:);
    referenceRocof = reference.rocofHzPerSecond(:);
    if any([numel(referencePhasor),numel(referenceFrequency), ...
            numel(referenceRocof)] ~= numel(synchrophasor))
        error('Reference sequences must match the estimator output length.');
    end
    if any(abs(referencePhasor) == 0)
        error('Reference phasor magnitudes must be nonzero.');
    end

    tvePercent = 100*abs(synchrophasor-referencePhasor) ./ ...
        abs(referencePhasor);
    feHz = frequencyHz-referenceFrequency;
    rfeHzPerSecond = rocofHzPerSecond-referenceRocof;

    validEvaluation = reportingIndex(isfinite(tvePercent(reportingIndex)) & ...
        isfinite(feHz(reportingIndex)) & ...
        isfinite(rfeHzPerSecond(reportingIndex)));
    errors = struct;
    errors.TVE_percent = tvePercent;
    errors.FE_Hz = feHz;
    errors.RFE_Hz_per_s = rfeHzPerSecond;
    errors.maximumTVE_percent = max(tvePercent(validEvaluation));
    errors.maximumAbsoluteFE_Hz = max(abs(feHz(validEvaluation)));
    errors.maximumAbsoluteRFE_Hz_per_s = ...
        max(abs(rfeHzPerSecond(validEvaluation)));
    result.errors = errors;
end
end
