# AFDSE-TVAF Dynamic Modulation Evaluation

This folder contains the test reported as Fig. 5 and Table V in the accompanying paper.

## Contents

- `AFDSE_TVAF_Pseudocode.m`: MATLAB-style processing sequence (framework);
- `filters/filter_responses.csv`: the amplitude-frequency responses of the three
  FIR low-pass filters of Table II;
- `results/TableV_dynamic_modulation_max_errors.csv`: the
  maximum TVE, FE and RFE at the three modulation frequencies printed in
Table V (0.5, 1.0 and 2.0 Hz);

## Test signal

x(t) = 100 [1 + 0.1 cos(2*pi*fm*t)] cos(2*pi*50*t - 0.1 cos(2*pi*fm*t)), i.e.
simultaneous amplitude and phase modulation with depth 0.1; fm = 0.1-2.0 Hz
(Table V lists 0.5, 1.0 and 2.0 Hz); sampling rate 10 kHz; record length 2 s.
